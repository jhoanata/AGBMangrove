# AGBMangrove

This repository contains a small set of files from the AvH project on aboveground biomass for Colombian mangroves leaded by Jhoanata Bolivar.